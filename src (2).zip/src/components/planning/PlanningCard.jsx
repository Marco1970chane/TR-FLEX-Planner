export default function PlanningCard({ dienst, onClick }) {
  return (
    <div className="dienst-card" onClick={onClick}>
      <strong>🚢 {dienst.terminal}</strong>

      <div>🕒 {dienst.dienst}</div>

      <small>{dienst.status}</small>
    </div>
  );
}